# Hello Friends Pharmacy — Website (Free: Firebase + Firebase Hosting)

Pure HTML/CSS/JS (कोई build ज़रूरी नहीं). Data: **Firebase Auth + Firestore** (Spark = free plan). Hosting: **Firebase Hosting** (free, `https://YOUR_PROJECT.web.app`).

## अभी देखना है? (Demo mode)
`js/firebase-config.js` में "YOUR_" लिखा रहने पर साइट demo mode में चलती है (data सिर्फ browser में).
`python3 -m http.server 8000` → http://localhost:8000
Demo logins: `admin@demo.com/admin123`, `rider@demo.com/rider123`, `customer@demo.com/cust123`

## Live करने के steps (≈15 मिनट)
1. https://console.firebase.google.com → **Add project** (Analytics बंद कर सकते हैं).
2. **Build → Authentication → Get started** → *Email/Password* enable (चाहें तो *Google* भी).
3. **Build → Firestore Database → Create database** (production mode, नज़दीकी region जैसे `asia-south1`).
4. **Project settings → Your apps → Web (</>)** → app register → मिला `firebaseConfig` को `js/firebase-config.js` में paste करें.
5. **Firestore → Rules** टैब में `firestore.rules` की पूरी file paste करके **Publish** करें.
6. **पहला Admin बनाना:** साइट पर अपने email से Sign up करें → Firebase Console → Firestore → `users` → अपना document खोलें → `role` को `admin` कर दें → logout/login.
7. Admin panel → **Settings**: दुकान का नाम, phone, WhatsApp (जैसे `919876543210`), UPI ID, पता, **store location (📍 button)**, delivery radius/fee भरें. फिर **Dashboard → Load sample products** (या अपने products जोड़ें).
8. **Delivery boy बनाना:** उसे साइट पर Sign up कराएँ → Admin → Users → role `delivery`.
9. **Deploy:**
   ```
   npm i -g firebase-tools
   firebase login
   firebase use --add        # अपना project चुनें
   firebase deploy           # hosting + firestore rules
   ```
   Authentication → Settings → **Authorized domains** में आपका `*.web.app` अपने-आप होता है. बाद में custom domain जोड़ना चाहें तो Hosting → Add custom domain.
10. `robots.txt` और `sitemap.xml` में `YOUR_PROJECT` को अपने असली domain से बदलें, फिर Google Search Console में sitemap submit करें (SEO).

## Roles (Role-based login)
| Role | क्या कर सकता है |
|---|---|
| **customer** (default, हर नया sign-up) | खरीदारी, cart, checkout, prescription upload, ऑर्डर track/cancel, review |
| **delivery** | सिर्फ अपने assigned orders, status update, live location share, navigate |
| **admin** | सब कुछ: orders, products, stock, offers, users/roles, settings, messages |

Role सिर्फ admin बदल सकता है — `firestore.rules` इसे server-side enforce करता है (browser में छेड़छाड़ से नहीं बदलेगा).

## Location-based tracking
- Customer checkout पर map में pin से सही location चुनता है; **delivery radius** (default 5 km) से बाहर ऑर्डर नहीं होता.
- Delivery boy "Start delivery" → "Share live location" दबाए; customer को **Track order** पेज पर मैप में 🛵 live दिखता है (OpenStreetMap + Leaflet, free).

## Features checklist (आपके form के अनुसार)
Hindi/English toggle · Medical theme (logo के लाल-हरे रंग) · Advanced home · About · Contact (+Google Maps, WhatsApp) · Categories · Search · Photos (upload/URL) · Price + MRP + discount · Cart · COD · Online payment (UPI + UTR) · WhatsApp order · Prescription upload (Rx order भी) · Customer login · Admin dashboard · Stock management (order confirm पर घटता, cancel पर वापस) · Order tracking · Local delivery · Reviews · Coupons/Offers · SEO (meta, JSON-LD, sitemap).

## ज़रूरी बातें
- **Firebase Storage इस्तेमाल नहीं किया** (नए projects में वह paid Blaze plan माँगता है). Product/prescription photos browser में छोटी करके Firestore में रखी जाती हैं — free plan में चलता है.
- **Online payment:** budget free होने से UPI (UPI ID पर भुगतान + UTR डालना) रखा है; admin "Mark paid" से verify करता है. बाद में Razorpay/Cashfree जोड़ सकते हैं (उसके लिए server/Cloud Function चाहिए).
- Free plan limits: Firestore 50K reads / 20K writes प्रतिदिन, 1 GiB data; Hosting 10 GB/माह. छोटी दुकान के लिए काफ़ी.
- Pharmacy का drug licence/नियम आपकी ज़िम्मेदारी है; Rx दवाइयाँ पर्चे के बिना न दें (साइट Rx products पर पर्चा माँगती है).
