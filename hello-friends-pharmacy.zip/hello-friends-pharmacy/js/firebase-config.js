// Firebase web config (यह public होता है; सुरक्षा firestore.rules से आती है)
export const firebaseConfig = {
  apiKey: "AIzaSyAcD9j_0gGrLa0g0y3JAjsFvJG-qEE-Itg",
  authDomain: "hello-friends-pharmacy.firebaseapp.com",
  projectId: "hello-friends-pharmacy",
  storageBucket: "hello-friends-pharmacy.firebasestorage.app",
  messagingSenderId: "188079334138",
  appId: "1:188079334138:web:24758d671d66d7e9665f43",
  measurementId: "G-MGYN2HHQ6Y"
};
