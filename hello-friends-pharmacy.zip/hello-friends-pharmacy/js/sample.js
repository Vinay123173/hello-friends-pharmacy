export const SAMPLE_PRODUCTS = [
  { name: "Paracetamol 500mg", nameHi: "पैरासिटामोल 500mg", category: "Medicines", price: 28, mrp: 32, stock: 120, pack: "Strip of 15 tablets", rx: false, emoji: "💊" },
  { name: "Cetirizine 10mg", nameHi: "सेटिरिज़िन 10mg", category: "Medicines", price: 24, mrp: 30, stock: 80, pack: "Strip of 10 tablets", rx: false, emoji: "💊" },
  { name: "ORS Electrolyte Powder", nameHi: "ओआरएस पाउडर", category: "Medicines", price: 21, mrp: 24, stock: 150, pack: "Sachet 21.8g", rx: false, emoji: "🧂" },
  { name: "Azithromycin 500mg", nameHi: "एज़िथ्रोमाइसिन 500mg", category: "Medicines", price: 98, mrp: 115, stock: 40, pack: "Strip of 3 tablets", rx: true, emoji: "💊" },
  { name: "Cough Syrup 100ml", nameHi: "खाँसी की सिरप", category: "Medicines", price: 85, mrp: 95, stock: 60, pack: "Bottle 100ml", rx: false, emoji: "🧴" },
  { name: "Vitamin C 500mg", nameHi: "विटामिन सी", category: "Vitamins & Supplements", price: 110, mrp: 135, stock: 70, pack: "60 chewable tablets", rx: false, emoji: "🍊" },
  { name: "Multivitamin Capsules", nameHi: "मल्टीविटामिन", category: "Vitamins & Supplements", price: 249, mrp: 310, stock: 50, pack: "30 capsules", rx: false, emoji: "💊" },
  { name: "Calcium + D3", nameHi: "कैल्शियम + D3", category: "Vitamins & Supplements", price: 145, mrp: 170, stock: 8, pack: "15 tablets", rx: false, emoji: "🦴" },
  { name: "Chyawanprash 500g", nameHi: "च्यवनप्राश", category: "Ayurvedic", price: 225, mrp: 260, stock: 35, pack: "Jar 500g", rx: false, emoji: "🍯" },
  { name: "Tulsi Drops", nameHi: "तुलसी ड्रॉप्स", category: "Ayurvedic", price: 90, mrp: 110, stock: 45, pack: "Bottle 30ml", rx: false, emoji: "🌿" },
  { name: "Baby Diapers (M)", nameHi: "बेबी डायपर", category: "Baby Care", price: 399, mrp: 480, stock: 25, pack: "Pack of 34", rx: false, emoji: "👶" },
  { name: "Baby Lotion 200ml", nameHi: "बेबी लोशन", category: "Baby Care", price: 175, mrp: 199, stock: 30, pack: "200ml", rx: false, emoji: "🧴" },
  { name: "Hand Sanitizer 250ml", nameHi: "हैंड सैनिटाइज़र", category: "Personal Care", price: 99, mrp: 130, stock: 90, pack: "250ml", rx: false, emoji: "🧼" },
  { name: "Digital Thermometer", nameHi: "डिजिटल थर्मामीटर", category: "Devices", price: 149, mrp: 220, stock: 20, pack: "1 unit", rx: false, emoji: "🌡️" },
  { name: "BP Monitor (Digital)", nameHi: "बीपी मशीन", category: "Devices", price: 1299, mrp: 1799, stock: 10, pack: "1 unit", rx: false, emoji: "🩺" },
  { name: "Bandage & Antiseptic Kit", nameHi: "फर्स्ट एड किट", category: "First Aid", price: 189, mrp: 240, stock: 40, pack: "Kit", rx: false, emoji: "🩹" }
];

export const SAMPLE_OFFERS = [
  { code: "WELCOME10", desc: "10% off on your first order above ₹199", type: "percent", value: 10, minOrder: 199, active: true },
  { code: "FLAT50", desc: "Flat ₹50 off on orders above ₹499", type: "flat", value: 50, minOrder: 499, active: true }
];
