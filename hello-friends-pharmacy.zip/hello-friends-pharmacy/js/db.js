// Data layer: Firebase (Auth + Firestore) या DEMO mode (localStorage)
import { firebaseConfig } from "./firebase-config.js";
import { SAMPLE_PRODUCTS, SAMPLE_OFFERS } from "./sample.js";

export const DEMO = !firebaseConfig.apiKey || firebaseConfig.apiKey.includes("YOUR_");
export const db = {};

export async function initDB() {
  Object.assign(db, DEMO ? demo() : await firebase());
  db.DEMO = DEMO;
  return db;
}

/* ---------------------------- FIREBASE ---------------------------- */
async function firebase() {
  const B = "https://www.gstatic.com/firebasejs/10.14.1/";
  const [{ initializeApp }, A, F] = await Promise.all([
    import(B + "firebase-app.js"), import(B + "firebase-auth.js"), import(B + "firebase-firestore.js")
  ]);
  const app = initializeApp(firebaseConfig), auth = A.getAuth(app), fs = F.getFirestore(app);
  const qOf = (c, q) => q && Object.keys(q).length
    ? F.query(F.collection(fs, c), ...Object.entries(q).map(([k, v]) => F.where(k, "==", v)))
    : F.collection(fs, c);
  const rows = s => s.docs.map(d => ({ ...d.data(), id: d.id }));
  let pending = null; // signup data while the auth listener fires

  async function profile(u) {
    const ref = F.doc(fs, "users", u.uid);
    let s = await F.getDoc(ref);
    if (!s.exists()) {
      const p = { name: pending?.name || u.displayName || "", phone: pending?.phone || "", email: u.email || "", role: "customer", createdAt: Date.now() };
      await F.setDoc(ref, p); pending = null;
      return { ...p, id: u.uid, uid: u.uid };
    }
    return { ...s.data(), id: u.uid, uid: u.uid };
  }
  return {
    mode: "firebase",
    list: async (c, q) => rows(await F.getDocs(qOf(c, q))),
    get: async (c, id) => { const s = await F.getDoc(F.doc(fs, c, id)); return s.exists() ? { ...s.data(), id: s.id } : null; },
    add: async (c, d) => (await F.addDoc(F.collection(fs, c), { ...d, createdAt: Date.now() })).id,
    set: (c, id, d) => F.setDoc(F.doc(fs, c, id), d, { merge: true }),
    update: (c, id, p) => F.updateDoc(F.doc(fs, c, id), p),
    remove: (c, id) => F.deleteDoc(F.doc(fs, c, id)),
    incr: (c, id, f, n) => F.updateDoc(F.doc(fs, c, id), { [f]: F.increment(n) }),
    listen: (c, q, cb) => F.onSnapshot(qOf(c, q), s => cb(rows(s)), e => console.error(e)),
    listenDoc: (c, id, cb) => F.onSnapshot(F.doc(fs, c, id), s => cb(s.exists() ? { ...s.data(), id: s.id } : null)),
    onAuth: cb => A.onAuthStateChanged(auth, async u => cb(u ? await profile(u) : null)),
    async signUp({ name, phone, email, password }) {
      pending = { name, phone };
      await A.createUserWithEmailAndPassword(auth, email, password);
    },
    signIn: ({ email, password }) => A.signInWithEmailAndPassword(auth, email, password),
    google: () => A.signInWithPopup(auth, new A.GoogleAuthProvider()),
    reset: email => A.sendPasswordResetEmail(auth, email),
    signOut: () => A.signOut(auth)
  };
}

/* ------------------------------ DEMO ------------------------------ */
function demo() {
  const K = "hfp_demo_", bus = new EventTarget(), uid = () => Math.random().toString(36).slice(2, 10);
  const read = c => { try { return JSON.parse(localStorage.getItem(K + c) || "[]"); } catch { return []; } };
  const write = (c, v) => { localStorage.setItem(K + c, JSON.stringify(v)); bus.dispatchEvent(new Event(c)); };
  const match = q => r => !q || Object.entries(q).every(([k, v]) => r[k] === v);
  const authCbs = new Set();
  const session = () => localStorage.getItem(K + "session");
  const me = () => { const id = session(); const u = read("users").find(x => x.id === id); return u ? pub(u) : null; };
  const pub = u => { const { password, ...p } = u; return { ...p, uid: u.id }; };
  const fire = () => authCbs.forEach(cb => cb(me()));

  if (!localStorage.getItem(K + "seeded")) {
    write("users", [
      { id: "u_admin", name: "Demo Admin", email: "admin@demo.com", phone: "9999900001", password: "admin123", role: "admin", createdAt: Date.now() },
      { id: "u_rider", name: "Demo Rider", email: "rider@demo.com", phone: "9999900002", password: "rider123", role: "delivery", createdAt: Date.now() },
      { id: "u_cust", name: "Demo Customer", email: "customer@demo.com", phone: "9999900003", password: "cust123", role: "customer", createdAt: Date.now() }
    ]);
    write("products", SAMPLE_PRODUCTS.map(p => ({ ...p, id: uid(), active: true, createdAt: Date.now() })));
    write("offers", SAMPLE_OFFERS.map(o => ({ ...o, id: uid() })));
    write("reviews", [{ id: uid(), uid: "u_cust", name: "Ramesh", rating: 5, text: "Bahut jaldi delivery mili, sab dawaiyan asli.", createdAt: Date.now() }]);
    localStorage.setItem(K + "seeded", "1");
  }
  window.addEventListener("storage", e => { if (e.key === K + "session") fire(); });

  return {
    mode: "demo",
    list: async (c, q) => read(c).filter(match(q)),
    get: async (c, id) => read(c).find(r => r.id === id) || null,
    add: async (c, d) => { const id = uid(); write(c, [...read(c), { ...d, id, createdAt: Date.now() }]); return id; },
    set: async (c, id, d) => {
      const a = read(c), i = a.findIndex(r => r.id === id);
      if (i < 0) a.push({ ...d, id }); else a[i] = { ...a[i], ...d };
      write(c, a);
    },
    update: async (c, id, p) => write(c, read(c).map(r => r.id === id ? { ...r, ...p } : r)),
    remove: async (c, id) => write(c, read(c).filter(r => r.id !== id)),
    incr: async (c, id, f, n) => write(c, read(c).map(r => r.id === id ? { ...r, [f]: (r[f] || 0) + n } : r)),
    listen(c, q, cb) {
      const f = () => cb(read(c).filter(match(q)));
      const s = e => { if (e.key === K + c) f(); };
      bus.addEventListener(c, f); window.addEventListener("storage", s); f();
      return () => { bus.removeEventListener(c, f); window.removeEventListener("storage", s); };
    },
    listenDoc(c, id, cb) {
      const f = () => cb(read(c).find(r => r.id === id) || null);
      const s = e => { if (e.key === K + c) f(); };
      bus.addEventListener(c, f); window.addEventListener("storage", s); f();
      return () => { bus.removeEventListener(c, f); window.removeEventListener("storage", s); };
    },
    onAuth(cb) { authCbs.add(cb); setTimeout(() => cb(me()), 0); return () => authCbs.delete(cb); },
    async signUp({ name, phone, email, password }) {
      if (read("users").some(u => u.email.toLowerCase() === email.toLowerCase())) throw new Error("This email is already registered.");
      if (password.length < 6) throw new Error("Password must be at least 6 characters.");
      const id = uid(); write("users", [...read("users"), { id, name, phone, email, password, role: "customer", createdAt: Date.now() }]);
      localStorage.setItem(K + "session", id); fire();
    },
    async signIn({ email, password }) {
      const u = read("users").find(x => x.email.toLowerCase() === email.toLowerCase() && x.password === password);
      if (!u) throw new Error("Wrong email or password.");
      localStorage.setItem(K + "session", u.id); fire();
    },
    google: async () => { throw new Error("Google sign-in works only with Firebase."); },
    reset: async () => { throw new Error("Password reset works only with Firebase."); },
    async signOut() { localStorage.removeItem(K + "session"); fire(); }
  };
}
