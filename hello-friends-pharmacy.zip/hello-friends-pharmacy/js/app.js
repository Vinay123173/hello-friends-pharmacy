import { db, initDB, DEMO } from "./db.js";
import { SAMPLE_PRODUCTS, SAMPLE_OFFERS } from "./sample.js";

/* ============================ helpers ============================ */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const inr = n => "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 });
const fmtDate = t => new Date(t).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
const stars = n => "★".repeat(n) + "☆".repeat(5 - n);
const view = h => { $("#view").innerHTML = h; };
const go = h => { location.hash = h; };
const toast = (m, err) => { const d = document.createElement("div"); d.textContent = m; if (err) d.className = "err"; $("#toast").append(d); setTimeout(() => d.remove(), 3500); };
const km = (a, b) => { const R = 6371, rad = x => x * Math.PI / 180, dLa = rad(b.lat - a.lat), dLo = rad(b.lng - a.lng); const h = Math.sin(dLa / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLo / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };

function compressImage(file, max = 700, q = 0.7) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onerror = rej;
    r.onload = () => {
      const im = new Image();
      im.onerror = rej;
      im.onload = () => {
        const s = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement("canvas");
        c.width = Math.round(im.width * s); c.height = Math.round(im.height * s);
        c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
        res(c.toDataURL("image/jpeg", q));
      };
      im.src = r.result;
    };
    r.readAsDataURL(file);
  });
}

/* ============================ i18n ============================ */
const T = {
  home: ["Home", "होम"], shop: ["Shop", "दुकान"], orders: ["My Orders", "मेरे ऑर्डर"], login: ["Login / Sign up", "लॉगिन / साइन अप"],
  logout: ["Logout", "लॉगआउट"], about: ["About", "हमारे बारे में"], contact: ["Contact", "संपर्क"], rx: ["Upload Prescription", "पर्चा अपलोड करें"],
  cart: ["Cart", "कार्ट"], delivery: ["Delivery Panel", "डिलीवरी पैनल"], admin: ["Admin", "एडमिन"],
  hero1: ["Your health, our", "आपकी सेहत,"], hero2: ["friendly care", "हमारी ज़िम्मेदारी"],
  hero_sub: ["Genuine medicines, home delivery, prescription upload & live order tracking.", "असली दवाइयाँ, घर तक डिलीवरी, पर्चा अपलोड और लाइव ऑर्डर ट्रैकिंग।"],
  search_ph: ["Search medicines, vitamins…", "दवाई, विटामिन खोजें…"], search: ["Search", "खोजें"],
  categories: ["Categories", "श्रेणियाँ"], all: ["All", "सभी"], offers: ["Offers & Discounts", "ऑफर और छूट"], popular: ["Popular products", "लोकप्रिय प्रोडक्ट"],
  why: ["Why choose us", "हमें क्यों चुनें"], reviews: ["Customer reviews", "ग्राहक समीक्षाएँ"], add: ["Add", "जोड़ें"], out: ["Out of stock", "स्टॉक खत्म"],
  low: ["Only few left", "कम स्टॉक"], needrx: ["Rx", "Rx"], empty_cart: ["Your cart is empty", "आपका कार्ट खाली है"], subtotal: ["Subtotal", "कुल (सब-टोटल)"],
  discount: ["Discount", "छूट"], dfee: ["Delivery fee", "डिलीवरी शुल्क"], total: ["Total", "कुल रकम"], free: ["FREE", "मुफ़्त"], checkout: ["Checkout", "चेकआउट"],
  wa_order: ["Order on WhatsApp", "WhatsApp पर ऑर्डर करें"], coupon: ["Coupon code", "कूपन कोड"], apply: ["Apply", "लगाएँ"],
  place: ["Place order", "ऑर्डर करें"], name: ["Full name", "पूरा नाम"], phone: ["Mobile number", "मोबाइल नंबर"], email: ["Email", "ईमेल"], password: ["Password", "पासवर्ड"],
  address: ["Delivery address", "डिलीवरी का पता"], pay: ["Payment method", "भुगतान का तरीका"], cod: ["Cash on Delivery", "कैश ऑन डिलीवरी"], upi: ["Online (UPI)", "ऑनलाइन (UPI)"],
  loc_btn: ["📍 Use my current location", "📍 मेरी लोकेशन लें"], loc_hint: ["Drag the pin to your exact doorstep.", "पिन को अपने घर के सही स्थान पर खिसकाएँ।"],
  track: ["Track order", "ऑर्डर ट्रैक करें"], cancel: ["Cancel order", "ऑर्डर रद्द करें"], signin: ["Sign in", "साइन इन"], signup: ["Create account", "खाता बनाएँ"],
  forgot: ["Forgot password?", "पासवर्ड भूल गए?"], google: ["Continue with Google", "Google से जारी रखें"], write_review: ["Write a review", "समीक्षा लिखें"],
  submit: ["Submit", "भेजें"], hours: ["Opening hours", "खुलने का समय"], send: ["Send message", "संदेश भेजें"], message: ["Message", "संदेश"],
  st_placed: ["Order placed", "ऑर्डर मिला"], st_confirmed: ["Confirmed", "कन्फर्म"], st_packed: ["Packed", "पैक हो गया"], st_out_for_delivery: ["Out for delivery", "डिलीवरी के लिए निकला"],
  st_delivered: ["Delivered", "डिलीवर हो गया"], st_cancelled: ["Cancelled", "रद्द"],
  f1: ["100% genuine medicines", "100% असली दवाइयाँ"], f2: ["Home delivery in your area", "आपके क्षेत्र में होम डिलीवरी"], f3: ["Live order tracking", "लाइव ऑर्डर ट्रैकिंग"], f4: ["COD & UPI payments", "COD और UPI भुगतान"]
};
let lang = localStorage.getItem("hfp_lang") || "hi";
const t = k => { const v = T[k]; return v ? v[lang === "hi" ? 1 : 0] : k; };
const CAT_HI = { "Medicines": "दवाइयाँ", "Vitamins & Supplements": "विटामिन और सप्लीमेंट", "Ayurvedic": "आयुर्वेदिक", "Baby Care": "बेबी केयर", "Personal Care": "पर्सनल केयर", "Devices": "मेडिकल उपकरण", "First Aid": "फर्स्ट एड" };
const CATS = Object.keys(CAT_HI);
const catName = c => lang === "hi" ? (CAT_HI[c] || c) : c;
const pname = p => (lang === "hi" && p.nameHi) ? p.nameHi : p.name;
const FLOW = ["placed", "confirmed", "packed", "out_for_delivery", "delivered"];

/* ============================ state ============================ */
const DEFAULTS = { name: "Hello Friends Pharmacy", phone: "", whatsapp: "", upi: "", address: "Set your address in Admin → Settings", hours: "9:00 AM – 10:00 PM", lat: 28.6139, lng: 77.209, radiusKm: 5, deliveryFee: 30, freeAbove: 499 };
const state = { user: null, products: [], offers: [], reviews: [], settings: { ...DEFAULTS }, coupon: null, loc: null, rx: null, adminTab: "dashboard", unsubs: [], maps: [] };
const cart = {
  get() { try { return JSON.parse(localStorage.getItem("hfp_cart") || "{}"); } catch { return {}; } },
  set(c) { localStorage.setItem("hfp_cart", JSON.stringify(c)); renderNav(); },
  count() { return Object.values(this.get()).reduce((a, b) => a + b, 0); },
  items() { const c = this.get(); return Object.entries(c).map(([id, qty]) => ({ p: state.products.find(x => x.id === id), qty })).filter(x => x.p); },
  clear() { this.set({}); }
};
const S = () => state.settings;
const waLink = txt => `https://wa.me/${(S().whatsapp || S().phone || "").replace(/\D/g, "")}?text=${encodeURIComponent(txt)}`;
const gmaps = l => `https://www.google.com/maps/search/?api=1&query=${l.lat},${l.lng}`;

function totals() {
  const sub = cart.items().reduce((a, { p, qty }) => a + p.price * qty, 0);
  let disc = 0; const c = state.coupon;
  if (c && sub >= (c.minOrder || 0)) disc = c.type === "percent" ? Math.round(sub * c.value) / 100 : Math.min(c.value, sub);
  const fee = sub === 0 ? 0 : (sub - disc >= S().freeAbove ? 0 : S().deliveryFee);
  return { sub, disc, fee, total: Math.max(0, sub - disc + fee) };
}

/* ============================ routing ============================ */
const pages = {};
function parseHash() {
  const h = location.hash.slice(1) || "/"; const [p, qs] = h.split("?"); const parts = p.split("/").filter(Boolean);
  return { page: parts[0] || "home", arg: parts[1], q: new URLSearchParams(qs || "") };
}
function cleanup() {
  state.unsubs.forEach(f => { try { f(); } catch { } }); state.unsubs = [];
  state.maps.forEach(m => { try { m.remove(); } catch { } }); state.maps = [];
  state.renderGrid = null;
}
async function route() {
  cleanup();
  const { page, arg, q } = parseHash();
  window.scrollTo(0, 0);
  renderNav();
  try { await (pages[page] || pages.home)(arg, q); }
  catch (e) { console.error(e); view(`<div class="wrap pad"><div class="alert err">⚠️ ${esc(e.message)}</div></div>`); }
}
function need(...roles) {
  if (!state.user) { go("#/login?next=" + parseHash().page); return false; }
  if (roles.length && !roles.includes(state.user.role)) { view(`<div class="wrap pad"><div class="alert err">🚫 This page is only for: ${roles.join(", ")}.</div></div>`); return false; }
  return true;
}
function mkMap(id, center, zoom = 15) {
  const m = L.map(id).setView([center.lat, center.lng], zoom);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap", maxZoom: 19 }).addTo(m);
  state.maps.push(m); setTimeout(() => m.invalidateSize(), 150);
  return m;
}
const pin = (e) => L.divIcon({ html: e, className: "pin", iconSize: [28, 28], iconAnchor: [14, 26] });

/* ============================ nav / footer ============================ */
function renderNav() {
  const u = state.user, r = u?.role, cur = parseHash().page;
  const a = (h, k, id) => `<a href="${h}" class="${cur === id ? "on" : ""}">${t(k)}</a>`;
  $("#nav").innerHTML = (DEMO ? `<div class="demo">⚙️ DEMO MODE — Firebase config अभी नहीं भरा है, data सिर्फ इसी browser में है। (js/firebase-config.js देखें)</div>` : "") + `
  <div class="wrap nav">
    <a class="brand" href="#/"><img src="assets/logo.jpg" alt="logo"><span>Hello <b>Friends</b> Pharmacy</span></a>
    <button class="burger" data-act="burger" aria-label="menu">☰</button>
    <nav class="links" id="links">
      ${a("#/", "home", "home")}${a("#/shop", "shop", "shop")}${a("#/rx", "rx", "rx")}
      ${r === "customer" ? a("#/orders", "orders", "orders") : ""}
      ${r === "delivery" ? a("#/delivery", "delivery", "delivery") : ""}
      ${r === "admin" ? a("#/admin", "admin", "admin") : ""}
      ${a("#/about", "about", "about")}${a("#/contact", "contact", "contact")}
      <a href="#/cart" class="${cur === "cart" ? "on" : ""}">🛒 ${t("cart")}<span class="badge">${cart.count()}</span></a>
      <button class="lk" data-act="lang">${lang === "hi" ? "EN" : "हिं"}</button>
      ${u ? `<button class="lk" data-act="logout">👤 ${esc((u.name || "").split(" ")[0] || "User")} · ${t("logout")}</button>` : `<a href="#/login" class="btn sm">${t("login")}</a>`}
    </nav>
  </div>`;
  $("#waFab").href = waLink("Hello! I need help with medicines.");
}
function renderFoot() {
  const s = S();
  $("#foot").innerHTML = `<div class="wrap grid g3">
    <div><b style="color:#fff;font-size:17px">${esc(s.name)}</b><p>${esc(s.address)}</p></div>
    <div><b style="color:#fff">${t("contact")}</b><p>📞 ${esc(s.phone || "—")}<br>💬 WhatsApp: ${esc(s.whatsapp || "—")}<br>🕒 ${esc(s.hours)}</p></div>
    <div><b style="color:#fff">Links</b><p><a href="#/shop">${t("shop")}</a> · <a href="#/rx">${t("rx")}</a> · <a href="#/about">${t("about")}</a> · <a href="#/contact">${t("contact")}</a></p>
    <p class="sm">⚕️ Medicines are dispensed as per Indian law. Prescription is required for Rx medicines.</p></div></div>
    <div class="wrap center sm" style="margin-top:14px;opacity:.7">© ${new Date().getFullYear()} ${esc(s.name)}</div>`;
}

/* ============================ product card ============================ */
function card(p) {
  const q = cart.get()[p.id] || 0, disc = p.mrp > p.price ? Math.round((1 - p.price / p.mrp) * 100) : 0, oos = p.stock <= 0;
  return `<div class="card pc">
    ${disc ? `<span class="off">${disc}% OFF</span>` : ""}${p.rx ? `<span class="rxb">℞ Rx</span>` : ""}
    <div class="img">${p.img ? `<img src="${esc(p.img)}" alt="${esc(p.name)}" loading="lazy">` : esc(p.emoji || "💊")}</div>
    <h4>${esc(pname(p))}</h4><div class="muted sm">${esc(p.pack || "")} · ${esc(catName(p.category))}</div>
    <div><span class="price">${inr(p.price)}</span>${p.mrp > p.price ? `<span class="mrp">${inr(p.mrp)}</span>` : ""}</div>
    ${oos ? `<span class="tag r">${t("out")}</span>` : p.stock < 10 ? `<span class="tag y">${t("low")}: ${p.stock}</span>` : ""}
    ${oos ? "" : q ? `<div class="stepper"><button data-act="dec" data-id="${p.id}">−</button><b>${q}</b><button data-act="inc" data-id="${p.id}">+</button></div>`
      : `<button class="btn sm" data-act="inc" data-id="${p.id}">🛒 ${t("add")}</button>`}
  </div>`;
}
const live = () => state.products.filter(p => p.active !== false);

/* ============================ PAGES ============================ */
pages.home = async () => {
  const feat = live().filter(p => p.stock > 0).slice(0, 8);
  view(`
  <section class="hero"><div class="wrap in">
    <div><span class="tag r">💚 ${esc(S().name)}</span>
      <h1>${t("hero1")} <span>${t("hero2")}</span></h1>
      <p class="muted">${t("hero_sub")}</p>
      <form class="searchbar" data-form="homeSearch"><input name="q" placeholder="${t("search_ph")}"><button class="btn">${t("search")}</button></form>
      <div class="row"><a class="btn red" href="#/rx">📄 ${t("rx")}</a><a class="btn ghost" href="#/shop">🛍️ ${t("shop")}</a>
      <a class="btn wa" target="_blank" rel="noopener" href="${waLink("Hello! I want to order medicines.")}">💬 WhatsApp</a></div>
    </div>
    <img class="lg" src="assets/logo.jpg" alt="Hello Friends Pharmacy">
  </div></section>
  <div class="wrap">
    <section class="sec"><h2 class="t">${t("categories")}</h2><div class="chips">${CATS.map(c => `<a class="chip" href="#/shop?cat=${encodeURIComponent(c)}">${catName(c)}</a>`).join("")}</div></section>
    ${state.offers.filter(o => o.active !== false).length ? `<section class="sec"><h2 class="t">${t("offers")}</h2><div class="grid g3">
      ${state.offers.filter(o => o.active !== false).map((o, i) => `<div class="offer ${i % 2 ? "r" : ""}"><b class="code">${esc(o.code)}</b><p style="margin:8px 0 0">${esc(o.desc)}</p></div>`).join("")}</div></section>` : ""}
    <section class="sec"><h2 class="t">${t("popular")}</h2><div class="grid products" id="grid"></div>
      <p class="center"><a class="btn ghost" href="#/shop">${t("shop")} →</a></p></section>
    <section class="sec"><h2 class="t">${t("why")}</h2><div class="grid g3">
      ${["💊 f1", "🏠 f2", "📍 f3", "💳 f4"].map(x => { const [e, k] = x.split(" "); return `<div class="card pad"><div style="font-size:30px">${e}</div><b>${t(k)}</b></div>`; }).join("")}</div></section>
    <section class="sec"><h2 class="t">${t("reviews")}</h2><div class="grid g3" id="revs"></div>
      <div class="card pad" style="margin-top:16px;max-width:560px"><b>${t("write_review")}</b>
        ${state.user ? `<form data-form="review"><label>Rating</label><select name="rating">${[5, 4, 3, 2, 1].map(n => `<option value="${n}">${stars(n)}</option>`).join("")}</select>
        <label>${t("message")}</label><textarea name="text" rows="2" required></textarea><p><button class="btn sm">${t("submit")}</button></p></form>`
      : `<p class="muted">Please <a href="#/login?next=home">login</a> to write a review.</p>`}</div></section>
    <section class="sec"><h2 class="t">📍 ${t("contact")}</h2><div id="hmap" class="map"></div></section>
  </div>`);
  state.renderGrid = () => { $("#grid").innerHTML = feat.map(card).join(""); }; state.renderGrid();
  $("#revs").innerHTML = state.reviews.slice(0, 6).map(r => `<div class="card pad"><div class="stars">${stars(r.rating)}</div><p>${esc(r.text)}</p><b class="sm">— ${esc(r.name)}</b></div>`).join("") || `<p class="muted">—</p>`;
  const m = mkMap("hmap", S()); L.marker([S().lat, S().lng], { icon: pin("🏪") }).addTo(m).bindPopup(esc(S().name));
};

pages.shop = async (_, q) => {
  let cat = q.get("cat") || "", term = q.get("q") || "";
  view(`<div class="wrap"><section class="sec">
    <div class="row"><input id="sq" class="grow" style="min-width:220px" placeholder="${t("search_ph")}" value="${esc(term)}"></div>
    <div class="chips" style="margin:14px 0"><span class="chip ${cat ? "" : "on"}" data-act="cat" data-c="">${t("all")}</span>${CATS.map(c => `<span class="chip ${cat === c ? "on" : ""}" data-act="cat" data-c="${esc(c)}">${catName(c)}</span>`).join("")}</div>
    <div class="grid products" id="grid"></div></section></div>`);
  state.renderGrid = () => {
    const x = term.toLowerCase();
    const list = live().filter(p => (!cat || p.category === cat) && (!x || (p.name + " " + (p.nameHi || "") + " " + (p.pack || "")).toLowerCase().includes(x)));
    $("#grid").innerHTML = list.map(card).join("") || `<p class="muted">No products found / कुछ नहीं मिला</p>`;
  };
  state.renderGrid();
  $("#sq").oninput = e => { term = e.target.value; state.renderGrid(); };
  state.setCat = c => { cat = c; document.querySelectorAll("[data-act=cat]").forEach(el => el.classList.toggle("on", el.dataset.c === c)); state.renderGrid(); };
};

pages.cart = async () => {
  const items = cart.items(), tt = totals();
  if (!items.length) return view(`<div class="wrap pad center"><h2>🛒 ${t("empty_cart")}</h2><a class="btn" href="#/shop">${t("shop")}</a></div>`);
  const needsRx = items.some(i => i.p.rx);
  view(`<div class="wrap"><section class="sec"><h2 class="t">🛒 ${t("cart")}</h2><div class="grid g2" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))">
    <div class="card pad">${items.map(({ p, qty }) => `<div class="line"><div style="font-size:30px">${p.img ? `<img src="${esc(p.img)}" width="46" height="46" style="border-radius:8px;object-fit:cover">` : esc(p.emoji || "💊")}</div>
      <div class="grow"><b>${esc(pname(p))}</b> ${p.rx ? `<span class="tag y">Rx</span>` : ""}<div class="muted sm">${inr(p.price)} × ${qty}</div></div>
      <div class="stepper" style="min-width:110px"><button data-act="dec" data-id="${p.id}">−</button><b>${qty}</b><button data-act="inc" data-id="${p.id}">+</button></div>
      <b>${inr(p.price * qty)}</b></div>`).join("")}</div>
    <div class="card pad sum"><div class="row"><input id="cp" class="grow" placeholder="${t("coupon")}" value="${esc(state.coupon?.code || "")}"><button class="btn sm" data-act="coupon">${t("apply")}</button></div>
      <div style="margin-top:12px"><div><span>${t("subtotal")}</span><span>${inr(tt.sub)}</span></div>
      ${tt.disc ? `<div><span>${t("discount")} (${esc(state.coupon.code)})</span><span>− ${inr(tt.disc)}</span></div>` : ""}
      <div><span>${t("dfee")}</span><span>${tt.fee ? inr(tt.fee) : t("free")}</span></div>
      <div class="tot"><span>${t("total")}</span><span>${inr(tt.total)}</span></div></div>
      ${tt.fee ? `<p class="muted sm">Free delivery above ${inr(S().freeAbove)}</p>` : ""}
      ${needsRx ? `<p class="alert">℞ Cart में Rx medicine है — checkout पर पर्चा (prescription) अपलोड करना होगा।</p>` : ""}
      <p><a class="btn block" href="#/checkout">${t("checkout")} →</a></p>
      <p><a class="btn wa block" target="_blank" rel="noopener" data-act="waCart" href="#">💬 ${t("wa_order")}</a></p></div></div></section></div>`);
  $('[data-act="waCart"]').href = waLink(
    `🛒 *New order — ${S().name}*\n\n` + items.map(({ p, qty }) => `• ${p.name} × ${qty} = ${inr(p.price * qty)}`).join("\n") +
    `\n\nTotal: ${inr(tt.total)}${state.loc ? `\n📍 Location: ${gmaps(state.loc)}` : ""}\n\nName: ${state.user?.name || ""}\nAddress: `);
};

pages.rx = async () => pages.checkout("rx");

pages.checkout = async (arg) => {
  const rxMode = arg === "rx";
  if (!need()) return;
  const items = rxMode ? [] : cart.items();
  if (!rxMode && !items.length) return go("#/cart");
  const tt = rxMode ? { sub: 0, disc: 0, fee: 0, total: 0 } : totals();
  const needsRx = rxMode || items.some(i => i.p.rx);
  state.rx = null;
  view(`<div class="wrap"><section class="sec"><h2 class="t">${rxMode ? "📄 " + t("rx") : "✅ " + t("checkout")}</h2>
  <form data-form="placeOrder" data-rx="${rxMode ? 1 : 0}" class="grid g2" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))">
    <div class="card pad">
      <label>${t("name")}</label><input name="name" required value="${esc(state.user.name)}">
      <label>${t("phone")}</label><input name="phone" required pattern="[0-9]{10}" maxlength="10" inputmode="numeric" value="${esc(state.user.phone || "")}">
      <label>${t("address")}</label><textarea name="address" rows="2" required placeholder="House no, street, landmark…"></textarea>
      <label>📍 Location</label><button type="button" class="btn ghost sm" data-act="geo">${t("loc_btn")}</button>
      <p class="muted sm" id="locinfo">${t("loc_hint")}</p><div id="cmap" class="map"></div>
    </div>
    <div class="card pad">
      ${needsRx ? `<label>📄 Prescription / पर्चा ${rxMode ? "*" : "* (Rx medicine)"}</label><input type="file" accept="image/*" id="rxf"><img id="rxp" class="rxprev" style="display:none">` : `<label>📄 Prescription (optional)</label><input type="file" accept="image/*" id="rxf"><img id="rxp" class="rxprev" style="display:none">`}
      ${rxMode ? `<p class="muted sm">पर्चा भेजने के बाद हमारा pharmacist आपको फोन करके दवाइयों और कीमत की पुष्टि करेगा।</p>` : ""}
      <label>${t("pay")}</label>
      <label class="row" style="font-weight:500;color:var(--ink)"><input type="radio" name="pay" value="cod" checked> ${t("cod")}</label>
      <label class="row" style="font-weight:500;color:var(--ink)"><input type="radio" name="pay" value="upi"> ${t("upi")}</label>
      <div id="upibox" style="display:none" class="alert ok">
        ${S().upi ? `Pay <b>${inr(tt.total)}</b> to UPI ID: <b>${esc(S().upi)}</b><br><a class="btn sm" style="margin:8px 0" href="upi://pay?pa=${encodeURIComponent(S().upi)}&pn=${encodeURIComponent(S().name)}&am=${tt.total}&cu=INR&tn=Order">Open UPI app</a>` : "UPI ID is not set yet — please choose COD."}
        <label>UTR / Transaction ID</label><input name="utr" placeholder="12-digit UTR"></div>
      ${rxMode ? "" : `<div class="sum" style="margin-top:14px"><div><span>${t("subtotal")}</span><span>${inr(tt.sub)}</span></div>${tt.disc ? `<div><span>${t("discount")}</span><span>− ${inr(tt.disc)}</span></div>` : ""}
      <div><span>${t("dfee")}</span><span>${tt.fee ? inr(tt.fee) : t("free")}</span></div><div class="tot"><span>${t("total")}</span><span>${inr(tt.total)}</span></div></div>`}
      <p><button class="btn red block" id="placeBtn">${t("place")}</button></p>
    </div></form></section></div>`);
  const start = state.loc || S(); state.loc = state.loc || null;
  const m = mkMap("cmap", start, 14);
  const mk = L.marker([start.lat, start.lng], { draggable: true, icon: pin("📍") }).addTo(m);
  L.circle([S().lat, S().lng], { radius: S().radiusKm * 1000, color: "#0b7a2f", fill: false, dashArray: "6" }).addTo(m);
  L.marker([S().lat, S().lng], { icon: pin("🏪") }).addTo(m);
  const setLoc = (la, lo, move) => {
    state.loc = { lat: la, lng: lo }; mk.setLatLng([la, lo]); if (move) m.setView([la, lo], 16);
    const d = km(S(), state.loc), ok = d <= S().radiusKm;
    $("#locinfo").innerHTML = `${ok ? "✅" : "❌"} ${d.toFixed(1)} km from store (we deliver within ${S().radiusKm} km)`; $("#locinfo").style.color = ok ? "" : "var(--r)";
  };
  mk.on("dragend", () => { const p = mk.getLatLng(); setLoc(p.lat, p.lng); });
  m.on("click", e => setLoc(e.latlng.lat, e.latlng.lng));
  state.setLoc = setLoc;
  document.querySelectorAll("[name=pay]").forEach(r => r.onchange = () => { $("#upibox").style.display = $("[name=pay]:checked").value === "upi" ? "" : "none"; });
  $("#rxf").onchange = async e => { const f = e.target.files[0]; if (!f) return; state.rx = await compressImage(f, 1000, 0.6); const i = $("#rxp"); i.src = state.rx; i.style.display = "block"; };
  if (state.loc) setLoc(state.loc.lat, state.loc.lng, true);
};

pages.login = async (_, q) => {
  if (state.user) return afterLogin();
  const tab = q.get("tab") === "up" ? "up" : "in";
  view(`<div class="wrap"><section class="sec"><div class="card pad" style="max-width:440px;margin:auto">
    <div class="tabs"><a class="tab ${tab === "in" ? "on" : ""}" href="#/login?tab=in&next=${q.get("next") || ""}">${t("signin")}</a><a class="tab ${tab === "up" ? "on" : ""}" href="#/login?tab=up&next=${q.get("next") || ""}">${t("signup")}</a></div>
    <form data-form="${tab === "in" ? "signin" : "signup"}">
      ${tab === "up" ? `<label>${t("name")}</label><input name="name" required><label>${t("phone")}</label><input name="phone" required pattern="[0-9]{10}" maxlength="10" inputmode="numeric">` : ""}
      <label>${t("email")}</label><input name="email" type="email" required><label>${t("password")}</label><input name="password" type="password" required minlength="6">
      <p><button class="btn block">${tab === "in" ? t("signin") : t("signup")}</button></p></form>
    ${tab === "in" ? `<p class="center sm"><a href="#" data-act="forgot">${t("forgot")}</a></p>` : ""}
    ${DEMO ? "" : `<button class="btn ghost block" data-act="google">🔐 ${t("google")}</button>`}
    ${DEMO ? `<div class="alert sm" style="margin-top:12px"><b>Demo logins:</b><br>Admin: admin@demo.com / admin123<br>Delivery: rider@demo.com / rider123<br>Customer: customer@demo.com / cust123</div>` : ""}
    <p class="muted sm center">New accounts are always <b>customer</b>. Admin / delivery role is given by the store owner.</p>
  </div></section></div>`);
};
function afterLogin() {
  const next = parseHash().q.get("next"), r = state.user.role;
  go(r === "admin" ? "#/admin" : r === "delivery" ? "#/delivery" : next ? "#/" + (next === "home" ? "" : next) : "#/");
}

pages.orders = async () => {
  if (!need("customer", "admin")) return;
  view(`<div class="wrap"><section class="sec"><h2 class="t">📦 ${t("orders")}</h2><div id="ol" class="grid"></div></section></div>`);
  state.unsubs.push(db.listen("orders", { uid: state.user.uid }, list => {
    list.sort((a, b) => b.createdAt - a.createdAt);
    $("#ol").innerHTML = list.map(o => `<div class="card pad"><div class="row between"><b>#${esc(o.orderNo)}</b><span class="tag ${o.status === "cancelled" ? "r" : o.status === "delivered" ? "" : "b"}">${t("st_" + o.status)}</span></div>
      <div class="muted sm">${fmtDate(o.createdAt)} · ${o.items.length ? o.items.map(i => `${esc(i.name)}×${i.qty}`).join(", ") : "Prescription order"}</div>
      <div class="row between" style="margin-top:8px"><b>${o.total ? inr(o.total) : "To be confirmed"}</b><span class="row"><a class="btn sm" href="#/track/${o.id}">📍 ${t("track")}</a>
      ${o.status === "placed" ? `<button class="btn sm red" data-act="cancelOrder" data-id="${o.id}">${t("cancel")}</button>` : ""}</span></div></div>`).join("") || `<p class="muted">No orders yet.</p>`;
  }));
};

pages.track = async (id) => {
  if (!need()) return;
  view(`<div class="wrap"><section class="sec"><h2 class="t">📍 ${t("track")}</h2><div class="grid g2" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))">
    <div class="card pad" id="tinfo"></div><div><div id="tmap" class="map" style="height:380px"></div><p class="muted sm" id="tnote"></p></div></div></section></div>`);
  let map, mkStore, mkCust, mkRider, first = true;
  state.unsubs.push(db.listenDoc("orders", id, o => {
    if (!o) return $("#tinfo").innerHTML = `<div class="alert err">Order not found.</div>`;
    const idx = FLOW.indexOf(o.status);
    $("#tinfo").innerHTML = `<div class="row between"><b>#${esc(o.orderNo)}</b><span class="tag b">${t("st_" + o.status)}</span></div>
      ${o.status === "cancelled" ? `<p class="alert err">${t("st_cancelled")}</p>` : `<ul class="tl" style="margin-top:14px">${FLOW.map((s, i) => `<li class="${i <= idx ? "done" : ""} ${i === idx ? "now" : ""}"><i></i>${t("st_" + s)}${o.history?.find(h => h.s === s) ? ` <span class="sm muted">· ${fmtDate(o.history.find(h => h.s === s).t)}</span>` : ""}</li>`).join("")}</ul>`}
      <p class="sm"><b>${esc(o.customer?.name)}</b> · ${esc(o.customer?.phone)}<br>${esc(o.address)}</p>
      ${o.items.length ? o.items.map(i => `<div class="row between sm"><span>${esc(i.name)} × ${i.qty}</span><span>${inr(i.price * i.qty)}</span></div>`).join("") + `<hr><div class="row between"><b>${t("total")}</b><b>${inr(o.total)}</b></div>` : ""}
      <p class="sm">💳 ${o.payment?.method === "upi" ? "UPI" : "COD"} · ${o.payment?.status === "paid" ? "✅ Paid" : "⏳ Pending"}</p>
      ${o.deliveryName ? `<p class="sm">🛵 ${esc(o.deliveryName)} ${o.deliveryPhone ? `· <a href="tel:${esc(o.deliveryPhone)}">${esc(o.deliveryPhone)}</a>` : ""}</p>` : ""}`;
    if (first) {
      map = mkMap("tmap", o.loc || S(), 14);
      mkStore = L.marker([S().lat, S().lng], { icon: pin("🏪") }).addTo(map).bindPopup("Store");
      if (o.loc) mkCust = L.marker([o.loc.lat, o.loc.lng], { icon: pin("🏠") }).addTo(map).bindPopup("Delivery address");
      first = false;
    }
    if (o.liveLoc && o.status === "out_for_delivery") {
      const ll = [o.liveLoc.lat, o.liveLoc.lng];
      if (!mkRider) { mkRider = L.marker(ll, { icon: pin("🛵") }).addTo(map).bindPopup("Delivery partner"); map.fitBounds(L.latLngBounds([ll, [o.loc.lat, o.loc.lng]]).pad(0.3)); } else mkRider.setLatLng(ll);
      $("#tnote").textContent = `🛵 Live location updated ${fmtDate(o.liveLoc.t)}` + (o.loc ? ` · ${km(o.liveLoc, o.loc).toFixed(1)} km away` : "");
    } else if (mkRider && o.status !== "out_for_delivery") { map.removeLayer(mkRider); mkRider = null; $("#tnote").textContent = ""; }
    else if (o.status === "out_for_delivery") $("#tnote").textContent = "Waiting for delivery partner's live location…";
  }));
};

pages.about = async () => view(`<div class="wrap"><section class="sec"><div class="card pad" style="max-width:820px;margin:auto"><div class="center"><img src="assets/logo.jpg" width="130" style="border-radius:50%"></div>
  <h2 class="center">${esc(S().name)}</h2>
  <p>${lang === "hi" ? "Hello Friends Pharmacy आपके मोहल्ले की भरोसेमंद दवा दुकान है। हम सिर्फ असली और लाइसेंस प्राप्त दवाइयाँ रखते हैं, ताकि आपके परिवार की सेहत सुरक्षित रहे। अब आप घर बैठे दवा मँगवा सकते हैं, पर्चा अपलोड कर सकते हैं और अपने ऑर्डर को लाइव मैप पर ट्रैक कर सकते हैं।"
    : "Hello Friends Pharmacy is your trusted neighbourhood medical store. We stock only genuine, licensed medicines so your family stays safe. Order from home, upload your prescription and track your order live on the map."}</p>
  <div class="grid g3">${["💊 f1", "🏠 f2", "📍 f3", "💳 f4"].map(x => { const [e, k] = x.split(" "); return `<div class="card pad center"><div style="font-size:28px">${e}</div>${t(k)}</div>`; }).join("")}</div></div></section></div>`);

pages.contact = async () => {
  const s = S();
  view(`<div class="wrap"><section class="sec"><h2 class="t">📞 ${t("contact")}</h2><div class="grid g2">
    <div class="card pad"><p>📍 ${esc(s.address)}</p><p>📞 <a href="tel:${esc(s.phone)}">${esc(s.phone || "—")}</a></p><p>🕒 ${t("hours")}: ${esc(s.hours)}</p>
      <p class="row"><a class="btn wa" target="_blank" rel="noopener" href="${waLink("Hello!")}">💬 WhatsApp</a><a class="btn ghost" target="_blank" rel="noopener" href="${gmaps(s)}">🗺️ Google Maps</a></p>
      <form data-form="contact"><label>${t("name")}</label><input name="name" required><label>${t("phone")}</label><input name="phone" required><label>${t("message")}</label><textarea name="text" rows="3" required></textarea><p><button class="btn">${t("send")}</button></p></form></div>
    <div id="cmap2" class="map" style="height:420px"></div></div></section></div>`);
  const m = mkMap("cmap2", s); L.marker([s.lat, s.lng], { icon: pin("🏪") }).addTo(m);
};

/* ---------------------------- DELIVERY ---------------------------- */
let share = { id: null, watch: null, last: 0 };
pages.delivery = async () => {
  if (!need("delivery", "admin")) return;
  view(`<div class="wrap"><section class="sec"><h2 class="t">🛵 ${t("delivery")}</h2><div id="dl" class="grid"></div></section></div>`);
  state.unsubs.push(db.listen("orders", { deliveryUid: state.user.uid }, list => {
    list.sort((a, b) => b.createdAt - a.createdAt);
    $("#dl").innerHTML = list.map(o => {
      const act = !["delivered", "cancelled"].includes(o.status);
      return `<div class="card pad"><div class="row between"><b>#${esc(o.orderNo)}</b><span class="tag b">${t("st_" + o.status)}</span></div>
      <p class="sm"><b>${esc(o.customer.name)}</b> · <a href="tel:${esc(o.customer.phone)}">${esc(o.customer.phone)}</a><br>${esc(o.address)}</p>
      <p class="sm">${o.items.map(i => `${esc(i.name)}×${i.qty}`).join(", ")} · <b>${inr(o.total)}</b> · ${o.payment.method === "cod" && o.payment.status !== "paid" ? "💵 Collect cash" : "✅ Paid"}</p>
      <div class="row"><a class="btn ghost sm" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=${o.loc.lat},${o.loc.lng}">🧭 Navigate</a>
      ${act && o.status !== "out_for_delivery" ? `<button class="btn sm" data-act="rStatus" data-id="${o.id}" data-s="out_for_delivery">🛵 Start delivery</button>` : ""}
      ${o.status === "out_for_delivery" ? `<button class="btn sm ${share.id === o.id ? "red" : ""}" data-act="shareLoc" data-id="${o.id}">${share.id === o.id ? "⏹ Stop sharing" : "📡 Share live location"}</button>
        <button class="btn sm" data-act="rStatus" data-id="${o.id}" data-s="delivered">✅ Delivered</button>` : ""}</div></div>`;
    }).join("") || `<p class="muted">No orders assigned to you yet.</p>`;
  }));
};

/* ------------------------------ ADMIN ------------------------------ */
pages.admin = async () => {
  if (!need("admin")) return;
  const tabs = ["dashboard", "orders", "products", "offers", "users", "messages", "settings"];
  view(`<div class="wrap"><section class="sec"><h2 class="t">⚙️ ${t("admin")}</h2>
    <div class="tabs">${tabs.map(x => `<span class="tab ${state.adminTab === x ? "on" : ""}" data-act="atab" data-tab="${x}">${x[0].toUpperCase() + x.slice(1)}</span>`).join("")}</div><div id="ab"></div></section></div>`);
  loadTab();
};
async function loadTab() {
  state.unsubs.forEach(f => f()); state.unsubs = [];
  document.querySelectorAll(".tab[data-tab]").forEach(el => el.classList.toggle("on", el.dataset.tab === state.adminTab));
  const el = $("#ab"); if (!el) return;
  const tab = state.adminTab;
  if (tab === "dashboard") {
    const [orders, users] = await Promise.all([db.list("orders"), db.list("users")]);
    const today = new Date().setHours(0, 0, 0, 0);
    const lowS = state.products.filter(p => p.stock < 10);
    el.innerHTML = `<div class="grid g3">
      ${[["Today's orders", orders.filter(o => o.createdAt >= today).length], ["Pending (new)", orders.filter(o => o.status === "placed").length], ["Revenue (delivered)", inr(orders.filter(o => o.status === "delivered").reduce((a, o) => a + o.total, 0))],
      ["Products", state.products.length], ["Low stock (<10)", lowS.length], ["Customers", users.filter(u => u.role === "customer").length]].map(([k, v]) => `<div class="card stat"><span class="muted sm">${k}</span><b>${v}</b></div>`).join("")}</div>
      ${lowS.length ? `<div class="card pad" style="margin-top:16px"><b>⚠️ Low stock</b><p class="sm">${lowS.map(p => `${esc(p.name)} (<span class="low">${p.stock}</span>)`).join(", ")}</p></div>` : ""}
      ${!state.products.length ? `<p><button class="btn" data-act="seed">➕ Load sample products & offers</button></p>` : ""}`;
  }
  if (tab === "orders") {
    const riders = (await db.list("users", { role: "delivery" }));
    state.riders = riders;
    state.unsubs.push(db.listen("orders", null, list => {
      list.sort((a, b) => b.createdAt - a.createdAt);
      el.innerHTML = list.map(o => `<div class="card pad" style="margin-bottom:12px"><div class="row between"><b>#${esc(o.orderNo)} · ${fmtDate(o.createdAt)}</b><span class="tag b">${t("st_" + o.status)}</span></div>
        <p class="sm"><b>${esc(o.customer.name)}</b> · ${esc(o.customer.phone)} · <a target="_blank" rel="noopener" href="${gmaps(o.loc)}">📍 map</a><br>${esc(o.address)}</p>
        <p class="sm">${o.items.length ? o.items.map(i => `${esc(i.name)}×${i.qty}`).join(", ") : "<i>Prescription-only order — call customer to confirm medicines & price</i>"} · <b>${o.total ? inr(o.total) : "—"}</b>${o.coupon ? ` (coupon ${esc(o.coupon)})` : ""}</p>
        <p class="sm">💳 ${o.payment.method.toUpperCase()} · ${o.payment.status === "paid" ? "✅ paid" : "⏳ pending"}${o.payment.utr ? ` · UTR ${esc(o.payment.utr)}` : ""}
          ${o.payment.status !== "paid" ? `<button class="btn sm ghost" data-act="markPaid" data-id="${o.id}">Mark paid</button>` : ""}
          ${o.rxImage ? `<button class="btn sm ghost" data-act="viewRx" data-id="${o.id}">📄 View prescription</button>` : ""}</p>
        <div class="row"><select data-change="oStatus" data-id="${o.id}" style="width:auto">${[...FLOW, "cancelled"].map(s => `<option value="${s}" ${o.status === s ? "selected" : ""}>${t("st_" + s)}</option>`).join("")}</select>
          <select data-change="oRider" data-id="${o.id}" style="width:auto"><option value="">— Assign rider —</option>${riders.map(r => `<option value="${r.id}" ${o.deliveryUid === r.id ? "selected" : ""}>${esc(r.name)}</option>`).join("")}</select></div></div>`).join("") || `<p class="muted">No orders yet.</p>`;
    }));
  }
  if (tab === "products") {
    el.innerHTML = `<p class="row"><button class="btn" data-act="editProduct" data-id="">➕ Add product</button>${state.products.length ? "" : `<button class="btn ghost" data-act="seed">Load samples</button>`}</p>
      <div class="card scroll"><table class="tbl"><tr><th></th><th>Name</th><th>Category</th><th>Price</th><th>MRP</th><th>Stock</th><th></th></tr>
      ${state.products.map(p => `<tr><td>${p.img ? `<img src="${esc(p.img)}" width="36" height="36" style="object-fit:cover;border-radius:6px">` : esc(p.emoji || "💊")}</td><td>${esc(p.name)} ${p.rx ? `<span class="tag y">Rx</span>` : ""} ${p.active === false ? `<span class="tag r">hidden</span>` : ""}</td><td>${esc(p.category)}</td><td>${inr(p.price)}</td><td>${inr(p.mrp)}</td>
      <td><input type="number" min="0" value="${p.stock}" data-change="stock" data-id="${p.id}" style="width:80px" class="${p.stock < 10 ? "low" : ""}"></td>
      <td><button class="btn sm ghost" data-act="editProduct" data-id="${p.id}">Edit</button> <button class="btn sm red" data-act="delProduct" data-id="${p.id}">✕</button></td></tr>`).join("")}</table></div>`;
  }
  if (tab === "offers") {
    state.offers = await db.list("offers");
    el.innerHTML = `<div class="card pad" style="margin-bottom:16px"><b>New coupon</b><form data-form="offer" class="grid g3">
      <div><label>Code</label><input name="code" required style="text-transform:uppercase"></div><div><label>Description</label><input name="desc" required></div>
      <div><label>Type</label><select name="type"><option value="percent">Percent %</option><option value="flat">Flat ₹</option></select></div>
      <div><label>Value</label><input name="value" type="number" min="1" required></div><div><label>Min order ₹</label><input name="minOrder" type="number" min="0" value="0"></div>
      <div style="align-self:end"><button class="btn">Save</button></div></form></div>
      <div class="card scroll"><table class="tbl"><tr><th>Code</th><th>Description</th><th>Value</th><th>Min</th><th>Active</th><th></th></tr>${state.offers.map(o => `<tr><td><b>${esc(o.code)}</b></td><td>${esc(o.desc)}</td><td>${o.type === "percent" ? o.value + "%" : inr(o.value)}</td><td>${inr(o.minOrder)}</td>
      <td><input type="checkbox" ${o.active !== false ? "checked" : ""} data-change="offerActive" data-id="${o.id}"></td><td><button class="btn sm red" data-act="delOffer" data-id="${o.id}">✕</button></td></tr>`).join("")}</table></div>`;
  }
  if (tab === "users") {
    const users = await db.list("users");
    el.innerHTML = `<p class="alert">Role देने के लिए: customer पहले साइन-अप करे → यहाँ role को <b>delivery</b> (डिलीवरी पार्टनर) या <b>admin</b> कर दें।</p>
      <div class="card scroll"><table class="tbl"><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th></tr>${users.map(u => `<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${esc(u.phone)}</td>
      <td><select data-change="role" data-id="${u.id}" style="width:auto" ${u.id === state.user.uid ? "disabled" : ""}>${["customer", "delivery", "admin"].map(r => `<option ${u.role === r ? "selected" : ""}>${r}</option>`).join("")}</select></td></tr>`).join("")}</table></div>`;
  }
  if (tab === "messages") {
    const ms = (await db.list("messages")).sort((a, b) => b.createdAt - a.createdAt);
    el.innerHTML = ms.map(m => `<div class="card pad" style="margin-bottom:10px"><b>${esc(m.name)}</b> · ${esc(m.phone)} · <span class="muted sm">${fmtDate(m.createdAt)}</span><p>${esc(m.text)}</p><button class="btn sm red" data-act="delMsg" data-id="${m.id}">Delete</button></div>`).join("") || `<p class="muted">No messages.</p>`;
  }
  if (tab === "settings") {
    const s = S();
    el.innerHTML = `<form data-form="settings" class="card pad grid g2">
      ${[["name", "Store name"], ["phone", "Phone"], ["whatsapp", "WhatsApp number (with country code, e.g. 919876543210)"], ["upi", "UPI ID (e.g. name@upi)"], ["address", "Address"], ["hours", "Opening hours"]].map(([k, l]) => `<div><label>${l}</label><input name="${k}" value="${esc(s[k])}"></div>`).join("")}
      <div><label>Store latitude</label><input name="lat" type="number" step="any" value="${s.lat}" id="slat"></div><div><label>Store longitude</label><input name="lng" type="number" step="any" value="${s.lng}" id="slng"></div>
      <div><label>Delivery radius (km)</label><input name="radiusKm" type="number" step="any" value="${s.radiusKm}"></div><div><label>Delivery fee ₹</label><input name="deliveryFee" type="number" value="${s.deliveryFee}"></div>
      <div><label>Free delivery above ₹</label><input name="freeAbove" type="number" value="${s.freeAbove}"></div>
      <div style="align-self:end" class="row"><button type="button" class="btn ghost" data-act="storeGeo">📍 Use my current location</button><button class="btn">Save settings</button></div></form>`;
  }
}

/* ============================ actions ============================ */
const actions = {
  burger: () => $("#links").classList.toggle("open"),
  lang: () => { lang = lang === "hi" ? "en" : "hi"; localStorage.setItem("hfp_lang", lang); renderFoot(); route(); },
  logout: async () => { await db.signOut(); go("#/"); },
  inc: ({ id }) => {
    const p = state.products.find(x => x.id === id), c = cart.get(); const n = (c[id] || 0) + 1;
    if (n > p.stock) return toast("Only " + p.stock + " in stock", true);
    c[id] = n; cart.set(c); refresh();
  },
  dec: ({ id }) => { const c = cart.get(); c[id] = (c[id] || 1) - 1; if (c[id] <= 0) delete c[id]; cart.set(c); refresh(); },
  cat: ({ c }) => state.setCat(c),
  coupon: () => {
    const code = $("#cp").value.trim().toUpperCase(), o = state.offers.find(x => x.code === code && x.active !== false);
    if (!o) { state.coupon = null; toast("Invalid coupon", true); } else if (totals().sub < (o.minOrder || 0)) { state.coupon = null; toast(`Minimum order ${inr(o.minOrder)}`, true); } else { state.coupon = o; toast("Coupon applied 🎉"); }
    route();
  },
  geo: () => {
    if (!navigator.geolocation) return toast("Location not supported", true);
    navigator.geolocation.getCurrentPosition(p => state.setLoc(p.coords.latitude, p.coords.longitude, true), () => toast("Location permission denied — drag the pin instead", true), { enableHighAccuracy: true, timeout: 12000 });
  },
  storeGeo: () => navigator.geolocation.getCurrentPosition(p => { $("#slat").value = p.coords.latitude; $("#slng").value = p.coords.longitude; }, () => toast("Permission denied", true)),
  forgot: async () => { const e = prompt("Enter your email"); if (e) try { await db.reset(e); toast("Reset link sent"); } catch (x) { toast(x.message, true); } },
  google: async () => { try { await db.google(); } catch (e) { toast(e.message, true); } },
  cancelOrder: async ({ id }) => {
    if (!confirm("Cancel this order?")) return;
    const o = await db.get("orders", id);
    await db.update("orders", id, { status: "cancelled", history: [...(o.history || []), { s: "cancelled", t: Date.now() }], updatedAt: Date.now() });
  },
  closeModal: () => { $("#modal").innerHTML = ""; },
  viewRx: async ({ id }) => { const o = await db.get("orders", id); modal(`<img class="full" src="${o.rxImage}">`); },
  markPaid: async ({ id }) => { const o = await db.get("orders", id); await db.update("orders", id, { payment: { ...o.payment, status: "paid" } }); },
  atab: ({ tab }) => { state.adminTab = tab; loadTab(); },
  seed: async () => {
    for (const p of SAMPLE_PRODUCTS) await db.add("products", { ...p, active: true });
    for (const o of SAMPLE_OFFERS) await db.add("offers", o);
    await loadData(); toast("Samples added"); loadTab();
  },
  editProduct: ({ id }) => {
    const p = state.products.find(x => x.id === id) || { category: "Medicines", active: true, stock: 0, emoji: "💊" };
    modal(`<h3>${id ? "Edit" : "Add"} product</h3><form data-form="product" data-id="${id || ""}" class="grid g2">
      <div><label>Name (English)</label><input name="name" required value="${esc(p.name)}"></div><div><label>नाम (Hindi, optional)</label><input name="nameHi" value="${esc(p.nameHi)}"></div>
      <div><label>Category</label><select name="category">${CATS.map(c => `<option ${p.category === c ? "selected" : ""}>${c}</option>`).join("")}</select></div><div><label>Pack / size</label><input name="pack" value="${esc(p.pack)}"></div>
      <div><label>Selling price ₹</label><input name="price" type="number" step="any" min="0" required value="${p.price ?? ""}"></div><div><label>MRP ₹</label><input name="mrp" type="number" step="any" min="0" value="${p.mrp ?? ""}"></div>
      <div><label>Stock</label><input name="stock" type="number" min="0" required value="${p.stock}"></div><div><label>Emoji (if no photo)</label><input name="emoji" value="${esc(p.emoji)}"></div>
      <div><label>Photo (upload)</label><input type="file" name="file" accept="image/*"></div><div><label>or Photo URL</label><input name="img" value="${p.img && !p.img.startsWith("data:") ? esc(p.img) : ""}"></div>
      <div style="grid-column:1/-1"><label class="row" style="color:var(--ink)"><input type="checkbox" name="rx" ${p.rx ? "checked" : ""}> Prescription required (Rx)</label>
      <label class="row" style="color:var(--ink)"><input type="checkbox" name="active" ${p.active !== false ? "checked" : ""}> Visible in shop</label></div>
      <div class="row"><button class="btn">Save</button><button type="button" class="btn ghost" data-act="closeModal">Cancel</button></div></form>`);
  },
  delProduct: async ({ id }) => { if (confirm("Delete this product?")) { await db.remove("products", id); await loadData(); loadTab(); } },
  delOffer: async ({ id }) => { await db.remove("offers", id); loadTab(); },
  delMsg: async ({ id }) => { await db.remove("messages", id); loadTab(); },
  rStatus: async ({ id, s }) => {
    const o = await db.get("orders", id), patch = { status: s, history: [...(o.history || []), { s, t: Date.now() }], updatedAt: Date.now() };
    if (s === "delivered") { patch.payment = { ...o.payment, status: "paid" }; stopShare(); }
    await db.update("orders", id, patch);
  },
  shareLoc: ({ id }) => {
    if (share.id === id) { stopShare(); return pages.delivery(); }
    if (!navigator.geolocation) return toast("Location not supported", true);
    stopShare(); share.id = id;
    share.watch = navigator.geolocation.watchPosition(p => {
      if (Date.now() - share.last < 8000) return; share.last = Date.now();
      db.update("orders", id, { liveLoc: { lat: p.coords.latitude, lng: p.coords.longitude, t: Date.now() }, updatedAt: Date.now() }).catch(e => console.error(e));
    }, () => toast("Location permission denied", true), { enableHighAccuracy: true, maximumAge: 5000 });
    toast("📡 Sharing live location");
  }
};
function stopShare() { if (share.watch != null) navigator.geolocation.clearWatch(share.watch); share = { id: null, watch: null, last: 0 }; }
function modal(h) { $("#modal").innerHTML = `<div class="box">${h}</div>`; }
function refresh() { if (state.renderGrid) state.renderGrid(); if (parseHash().page === "cart") route(); }

document.addEventListener("click", e => {
  if (e.target.id === "modal") return actions.closeModal();
  const b = e.target.closest("[data-act]"); if (!b) return;
  if (b.tagName === "A" && b.getAttribute("href") === "#") e.preventDefault();
  actions[b.dataset.act]?.({ ...b.dataset }, b, e);
});
document.addEventListener("change", async e => {
  const el = e.target.closest("[data-change]"); if (!el) return; const id = el.dataset.id;
  try {
    switch (el.dataset.change) {
      case "stock": await db.update("products", id, { stock: Math.max(0, +el.value || 0) }); await loadData(); toast("Stock updated"); break;
      case "role": await db.update("users", id, { role: el.value }); toast("Role updated"); break;
      case "offerActive": await db.update("offers", id, { active: el.checked }); break;
      case "oRider": { const r = state.riders.find(x => x.id === el.value); await db.update("orders", id, { deliveryUid: el.value || null, deliveryName: r?.name || "", deliveryPhone: r?.phone || "", updatedAt: Date.now() }); toast("Rider assigned"); break; }
      case "oStatus": await setOrderStatus(id, el.value); break;
    }
  } catch (x) { toast(x.message, true); }
});
async function setOrderStatus(id, s) {
  const o = await db.get("orders", id);
  if (o.status === s) return;
  const patch = { status: s, history: [...(o.history || []), { s, t: Date.now() }], updatedAt: Date.now() };
  // stock: confirm होने पर घटता है, cancel होने पर वापस जुड़ता है
  if (s !== "placed" && s !== "cancelled" && !o.stockDeducted) { for (const i of o.items) await db.incr("products", i.id, "stock", -i.qty); patch.stockDeducted = true; }
  if (s === "cancelled" && o.stockDeducted) { for (const i of o.items) await db.incr("products", i.id, "stock", i.qty); patch.stockDeducted = false; }
  if (s === "delivered" && o.payment.method === "cod") patch.payment = { ...o.payment, status: "paid" };
  await db.update("orders", id, patch); await loadData(); toast("Order updated");
}

/* ============================ forms ============================ */
const forms = {
  homeSearch: f => go("#/shop?q=" + encodeURIComponent(f.q.value)),
  async signin(f) { await db.signIn({ email: f.email.value.trim(), password: f.password.value }); },
  async signup(f) { await db.signUp({ name: f.name.value.trim(), phone: f.phone.value.trim(), email: f.email.value.trim(), password: f.password.value }); },
  async review(f) {
    await db.add("reviews", { uid: state.user.uid, name: state.user.name || "Customer", rating: +f.rating.value, text: f.text.value.trim() });
    state.reviews = (await db.list("reviews")).sort((a, b) => b.createdAt - a.createdAt); toast("Thank you! 💚"); route();
  },
  async contact(f) { await db.add("messages", { name: f.name.value, phone: f.phone.value, text: f.text.value }); f.reset(); toast("Message sent ✔"); },
  async offer(f) {
    await db.add("offers", { code: f.code.value.trim().toUpperCase(), desc: f.desc.value, type: f.type.value, value: +f.value.value, minOrder: +f.minOrder.value || 0, active: true });
    toast("Coupon saved"); loadData().then(loadTab);
  },
  async settings(f) {
    const d = {}; new FormData(f).forEach((v, k) => d[k] = ["lat", "lng", "radiusKm", "deliveryFee", "freeAbove"].includes(k) ? +v : v);
    await db.set("settings", "store", d); state.settings = { ...DEFAULTS, ...d }; renderFoot(); toast("Settings saved ✔");
  },
  async product(f) {
    const d = { name: f.name.value.trim(), nameHi: f.nameHi.value.trim(), category: f.category.value, pack: f.pack.value.trim(), price: +f.price.value, mrp: +f.mrp.value || +f.price.value,
      stock: +f.stock.value, emoji: f.emoji.value || "💊", rx: f.rx.checked, active: f.active.checked };
    const file = f.file.files[0];
    if (file) d.img = await compressImage(file, 500, 0.7); else if (f.img.value.trim()) d.img = f.img.value.trim(); else if (f.dataset.id) d.img = state.products.find(p => p.id === f.dataset.id)?.img || "";
    if (f.dataset.id) await db.set("products", f.dataset.id, d); else await db.add("products", d);
    actions.closeModal(); await loadData(); toast("Product saved ✔"); loadTab();
  },
  async placeOrder(f) {
    const rxMode = f.dataset.rx === "1", items = rxMode ? [] : cart.items(), tt = rxMode ? { sub: 0, disc: 0, fee: 0, total: 0 } : totals();
    const needsRx = rxMode || items.some(i => i.p.rx);
    if (!state.loc) return toast("📍 Please set your delivery location on the map", true);
    const d = km(S(), state.loc); if (d > S().radiusKm) return toast(`Sorry, we deliver only within ${S().radiusKm} km (you are ${d.toFixed(1)} km away)`, true);
    if (needsRx && !state.rx) return toast("📄 Please upload your prescription", true);
    for (const { p, qty } of items) if (qty > p.stock) return toast(`${p.name}: only ${p.stock} left`, true);
    const method = f.pay.value; if (method === "upi" && !S().upi) return toast("UPI not available — choose COD", true);
    if (method === "upi" && !f.utr.value.trim()) return toast("Enter UTR / transaction ID after paying", true);
    $("#placeBtn").disabled = true;
    const order = {
      orderNo: "HF" + Date.now().toString().slice(-8), uid: state.user.uid, type: rxMode ? "rx" : "cart",
      customer: { name: f.name.value.trim(), phone: f.phone.value.trim(), email: state.user.email || "" }, address: f.address.value.trim(), loc: state.loc,
      items: items.map(({ p, qty }) => ({ id: p.id, name: p.name, price: p.price, qty })), subtotal: tt.sub, discount: tt.disc, coupon: tt.disc ? state.coupon.code : "", deliveryFee: tt.fee, total: tt.total,
      payment: { method, status: "pending", utr: method === "upi" ? f.utr.value.trim() : "" }, rxImage: state.rx || "", status: "placed", history: [{ s: "placed", t: Date.now() }], deliveryUid: null, liveLoc: null, updatedAt: Date.now()
    };
    try {
      const id = await db.add("orders", order);
      if (!rxMode) cart.clear(); state.coupon = null; state.rx = null; toast("🎉 Order placed!"); go("#/track/" + id);
    } catch (e) { $("#placeBtn").disabled = false; throw e; }
  }
};
document.addEventListener("submit", async e => {
  const f = e.target.closest("form[data-form]"); if (!f) return; e.preventDefault();
  try { await forms[f.dataset.form](f); } catch (x) { console.error(x); toast(x.message.replace("Firebase: ", ""), true); }
});

/* ============================ boot ============================ */
async function loadData() {
  const [prods, offers, revs, st] = await Promise.all([db.list("products"), db.list("offers"), db.list("reviews"), db.get("settings", "store")]);
  state.products = prods.sort((a, b) => a.name.localeCompare(b.name)); state.offers = offers;
  state.reviews = revs.sort((a, b) => b.createdAt - a.createdAt); state.settings = { ...DEFAULTS, ...(st || {}) };
  state.products.forEach(p => { p.price = +p.price; p.mrp = +p.mrp; p.stock = +p.stock; });
}
(async function boot() {
  try {
    await initDB(); await loadData();
  } catch (e) { console.error(e); view(`<div class="wrap pad"><div class="alert err">⚠️ Could not start: ${esc(e.message)}<br>Check js/firebase-config.js and Firestore rules.</div></div>`); return; }
  renderFoot(); renderNav();
  let firstAuth = true;
  db.onAuth(async u => {
    const was = state.user; state.user = u;
    if (u && !was && parseHash().page === "login") return afterLogin();
    if (firstAuth || (!!u !== !!was)) { firstAuth = false; route(); } else renderNav();
  });
  window.addEventListener("hashchange", route);
})();
